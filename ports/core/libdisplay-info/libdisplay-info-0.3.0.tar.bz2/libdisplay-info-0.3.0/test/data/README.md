# Test data

The following blobs originate from the [linuxhw/EDID] repository and are
licensed under the [Creative Commons Attribution 4.0 International][CC-BY-4.0]
license:

name | source | source commit
---- | ------ | -------------
acer-p1276		| ./Analog/Acer/ACR1616/4108C2D271EB		| cff7fe4d44
goldstar-37lg5000       | ./Digital/Goldstar/GSM75F2/7E4E421EBEFD       | a4a460983d
goldstar-ite6604-hdmi	| ./Digital/Goldstar/GSM7666/FE91A60D5B6E	| cff7fe4d44
hitachi-55r6+		| ./Digital/Hitachi/HEC0000/58C711CBA787	| cff7fe4d44
lenovo-t27p10           | ./Digital/Lenovo/LEN61DA/75037CFDD4F5         | 6074fb4434
msi-mag321curv-dp	| ./Digital/MSI/MSI3DA2/9BD6EC4AFDBD		| cff7fe4d44
panasonic-mei96a2-dp	| ./Digital/Panasonic/MEI96A2/7CA47BE65E1E	| cff7fe4d44
philips-ftv-2017	| ./Digital/Philips/PHL0000/CDF43E0C4634	| cff7fe4d44
philips-ftv-490		| ./Digital/Philips/PHL01EA/03A4224323A6	| cff7fe4d44
samsung-odyssey-g60sd   | ./Digital/Samsung/SAM75C3/D3961D5B60BC        | f295649735
samsung-s27a950d-dp	| ./Digital/Samsung/SAM079F/6D343EDB39F8	| cff7fe4d44
sun-gh19ps-dvi		| ./Digital/Sun/SUN058C/34B2E3B9A052		| cff7fe4d44
tcl-smart-tv-5655	| ./Digital/TCL/TCL5655/1723FF2DC6D1		| cff7fe4d44
viewsonic-vp2768-dp	| ./Digital/ViewSonic/VSC2034/6B81BEA28A1E	| cff7fe4d44
vizio-d40fj09           | ./Digital/Vizio/VIZ1044/F82F2A538C85          | c430d65898

The following blobs originate from the [edid-decode] repository and are under
the same license as the rest of the libdisplay-info project:

name | source | source commit
---- | ------ | -------------
apple-xdr-dp			| ./data/apple-xdr-6k-tile0	| 894eefd
cta-timings			| ./test/cta-timings.test	| 894eefd
cta-vfpdb			| ./test/cta-vfpdb.test		| 894eefd
custom-uncommon-cta-vesa	| ./test/cta-vesa.test		| 894eefd
dell-2408wfp-dp			| ./data/dell-2408wfp-dp	| 894eefd
samsung-q800t-hdmi2.0		| ./data/samsung-q800t-hdmi2.0	| 894eefd

The other blobs are under the same license as the rest of the libdisplay-info
project:

name | source
---- | ------
amazon-fire-tv-48	| display
ayaneo-wxga		| display
cvt			| handcrafted
goldstar-e2441		| display
hisense-55u8k		| display
hp-5dq99aa-hdmi		| display
jdi-lpm135m467-edp	| display
philips-4k-2023		| display
qemu			| generated
samsung-qn900b-8k	| display

[linuxhw/EDID]: https://github.com/linuxhw/EDID
[edid-decode]: https://git.linuxtv.org/edid-decode.git
[CC-BY-4.0]: LICENSE.CC-BY-4.0
